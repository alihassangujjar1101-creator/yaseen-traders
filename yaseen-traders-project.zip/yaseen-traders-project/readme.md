# Yaseen Traders – Web Development Project

This is a **demo website** showcasing my skills in **HTML, CSS, and front-end web development**. 
The website represents a professional business page for **Yaseen Traders**, an authorized distributor of **Golden Pearl** skincare and beauty products in Pakistan.

---

## 🔹 Live Demo

You can view the website live on GitHub Pages: 
[https://YOUR_USERNAME.github.io/yaseen-traders-project/](https://YOUR_USERNAME.github.io/yaseen-traders-project/)

---

## 🔹 Features

- **Modern and responsive layout** using HTML & CSS 
- **Hero section** with welcome text and autoplay video 
- **Golden Pearl points section** highlighting products & services 
- **Product showcase section** with cards for multiple products 
- **Professional header and navigation bar** 
- **Footer with copyright information** 
- **Clean yellow/black theme** for a professional look 

---

## 🔹 Skills Demonstrated

- HTML5 structure and semantic elements 
- CSS3 styling (Flexbox, Grid, colors, spacing) 
- Video embedding & media controls 
- Responsive and visually appealing layout design 
- Project organization & folder structure 

---

## 🔹 Folder Structure
yaseen-traders/
│
├── 1.backend/                     # Backend folder (Node.js server)
│   ├── node_modules/              # Installed npm packages
│   ├── order.js                   # Order handling logic
│   ├── orders.json                 # Orders database (JSON file)
│   ├── package.json               # Node.js project config & dependencies
│   └── server.js                  # Express server / API endpoints
│
├── 2.frontend/                    # Frontend folder (HTML/CSS/JS)
│   ├── index.html                 # Home page
│   ├── admin.html                 # Admin panel / dashboard
│   ├── login.html                 # Login page
│   ├── singup.html                # Signup page
│   ├── contact.html               # Contact form page
│   ├── item.html                  # Item list / products overview
│   ├── oil.html                   # Product category: Hair Oil
│   ├── shampoo.html               # Product category: Shampoo
│   ├── haircolor.html             # Product category: Hair Color
│   ├── hairoff.html               # Product category: Hair Serum / Treatments
│   ├── mask.html                  # Product category: Hair Mask
│   └── setandtouch.html           # Product category: Sets & Touch-ups
│
├── 3.picture/                     # All images for website
│   ├── logo.jpeg
│   ├── product1.jpg
│   ├── product2.jpg
│   ├── product3.jpg
│   ├── product4.jpg
│   ├── product5.jpg
│   ├── product6.jpg
│   ├── product7.jpg
│   ├── product8.jpg
│   ├── product9.jpg
│   └── product10.jpg
│
└── README.md                      # Project description & instructions




---

## 🔹 About This Project

Yaseen Traders is an **authorized distributor of Golden Pearl products**, known for quality and dermatologically tested skincare solutions.  
This project is designed to **demonstrate my front-end development skills**, including layout design, video integration, and visually appealing content organization.

---

## 🔹 How to Run Locally

1. Clone the repository:

```bash
git clone https://github.com/Ali hassan/yaseen-traders-project.git


  ## '  Navegation

/home/gujjar/Desktop/yaseen-traders/pictures/ChatGPT Image Jan 6, 2026, 03_01_57 AM.png

