
const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');

const app = express();
const PORT = 3000;


app.use(express.json());
app.use(cors());

mongoose.connect('mongodb://127.0.0.1:27017/yaseenTraders')
    .then(() => console.log(" MongoDB connected"))
    .catch(err => console.log(" MongoDB error:", err));


app.get('/', (req, res) => {
    res.send('Backend running ');
});


app.post('/signup', (req, res) => {
    const { name, email, password } = req.body;
    if (!name || !email || !password) {
        return res.status(400).json({ message: "All fields are required" });
    }
    console.log("📝 NEW USER SIGNUP:", { name, email, password });
    res.json({ message: "Signup successful ✅" });
});

app.post('/login', (req, res) => {
    const { email, password } = req.body;
    if (!email || !password) {
        return res.status(400).json({ message: "Email and password required" });
    }
    console.log("🔑 LOGIN ATTEMPT:", { email, password });
    res.json({ message: "Login successful ✅" });
});

app.post('/contact', (req, res) => {
    const { name, email, subject, message } = req.body;
    if (!name || !email || !subject || !message) {
        return res.status(400).json({ message: "All fields are required" });
    }
    console.log("✉️ NEW CONTACT MESSAGE:", { name, email, subject, message, timestamp: new Date().toLocaleString() });
    res.json({ message: "Message sent successfully ✅" });
});


const orderSchema = new mongoose.Schema({
    name: String,
    phone: String,
    email: String,
    city: String,
    address: String,
    product: String,
    price: Number,
    quantity: Number,
    total: Number,
    payment: String,
    orderId: String,
    timestamp: { type: Date, default: Date.now }
});
const Order = mongoose.model('Order', orderSchema);


app.post('/order', async (req, res) => {
    const { name, phone, email, city, address, product, price, quantity, total, payment } = req.body;
    if (!name || !phone || !address || !product || !price || !quantity || !total) {
        return res.status(400).json({ message: "All fields required" });
    }

    const orderId = 'YT-' + Date.now(); 

    try {
        const newOrder = new Order({ name, phone, email, city, address, product, price, quantity, total, payment, orderId });
        await newOrder.save();

        console.log("📦 NEW ORDER SAVED:", { name, product, total, orderId });
        res.json({ message: `Order placed ✅ | Order ID: ${orderId}` });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: "Server error, order not saved" });
    }
});


app.get('/admin/orders', async (req, res) => {
    try {
        const orders = await Order.find().sort({ timestamp: -1 }); 
        res.json(orders);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: "Server error" });
    }
});



app.listen(PORT, () => {
    console.log(`Backend running on http://localhost:${PORT}`);
});
